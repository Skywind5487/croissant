package net.fabricmc.croissant.item;

import net.minecraft.item.FoodComponent;

public class ModFoodConponents {
    public static final FoodComponent CROISSANT = new FoodComponent.Builder().hunger(4).saturationModifier(0.3f).build();
}
